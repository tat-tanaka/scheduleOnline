package jp.co.wiss1.common;

public class WISS1CommonConst {

}
